<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Task Form</title>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" href="toastr.min.css">
  <script src="jquery.3.7.1.min.js"></script>
  <script src="toastr.min.js"></script>
  <script src="https://code.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="add_task.css">
</head>
<body>
</script>

<div class="container">
  <h2>Add Task</h2>

  <form id="taskForm" action="#" method="post">
    <div class="form-group">
      <label for="taskName">Task Name:</label>
      <input type="text" id="taskName" name="taskName" required>
    </div>
    <div class="form-group">
      <label for="description">Description:</label>
      <textarea id="description" name="description" rows="4" required></textarea>
    </div>
    <div class="form-group">
      <label for="priority">Priority:</label>
      <select id="priority" name="priority" required>
        <option value="" disabled selected>-- Select Priority --</option>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
    </div>
    <div class="form-group">
      <label for="status">Status:</label>
      <select id="status" name="status" required>
            <option value="" disabled selected>-- Select Status --</option>
            <option value="inactive">Inactive</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
      </select>
    </div>
    <div class="form-group">
      <button type="submit" name="add_task">Add Task</button>
    </div>
  </form>
</div>
<script src="sweetalert.js"></script>

<script>
  swal(<?php echo $_SESSION['title'];?>, <?php echo $_SESSION['status'];?>, <?php echo $_SESSION['status_code'];?>);
</script>
</body>
</html>

<?php 

include('toast.php');

include ('connection.php');
$id=$_GET['id'];

if(isset($_POST['add_task'])){
    $taskName=$_POST['taskName'];
    $description=$_POST['description'];
    $priority=$_POST['priority'];
    $status=$_POST['status'];
    $date=date('Y.m.d h:i:sa');

    if(empty($taskName) || empty($description || empty($priority) || empty($status) )){
      
      exit;
    }
    else{
      $add_task="INSERT INTO `task`(`u_id`, `task`, `description`, `priority`, `status`, `date`) VALUES ('$id','$taskName','$description','$priority','$status','$date')";
      $result=mysqli_query($connection,$add_task);
      
      echo "<script>
      window.location.href = 'index.php';
      alert('Data Inserted Successfully!');
      </script>";
    }

    
    
}
?>

<?php 

if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
  echo $_SESSION['status'];
  unset($_SESSION['status']);
}

?>