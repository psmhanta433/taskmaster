-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Feb 14, 2024 at 05:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_master`
--

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(4) NOT NULL,
  `u_id` int(4) NOT NULL,
  `task` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `priority` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `u_id`, `task`, `description`, `priority`, `status`, `date`) VALUES
(11, 3, 'Demo 2', 'Demo jdgn dsfngi', 'medium', 'completed', '2023-12-20 05:26:28'),
(14, 1, 'Phone', '9373400752', 'medium', 'active', '2023-12-20 11:17:50'),
(16, 1, 'Phone', 'v b,fhgkld', 'medium', 'inactive', '2023-12-20 11:58:48'),
(17, 1, 'Phone', 'fn gerg', 'low', 'active', '2023-12-20 12:00:22'),
(32, 1, 'Phone', 'm herskg', 'high', 'inactive', '2023-12-21 02:16:27'),
(33, 1, 'lh jtlrkhyrl', 'fg d,tjhiordth', 'medium', 'inactive', '2023-12-21 02:16:37'),
(35, 1, 'Phone', 'hkjfdhjkdtrhk', 'low', 'active', '2023-12-21 03:56:06'),
(36, 1, 'Phone', 'fhjg dfj', 'medium', 'active', '2023-12-21 04:03:54'),
(37, 1, 'Phone', 'fhjg dfj', 'medium', 'active', '2023-12-21 04:04:55'),
(38, 1, 'Phone', 'fmg jktgh', 'low', 'active', '2023-12-21 04:14:21'),
(39, 1, 'Phone', 'fmg jktgh', 'low', 'active', '2023-12-21 04:15:26'),
(40, 1, 'Phone', 'fmg jktgh', 'low', 'active', '2023-12-21 04:15:51'),
(41, 1, 'Phone', 'fmg jktgh', 'low', 'active', '2023-12-21 04:16:34'),
(62, 1, 'ABC', 'e rwr wefwe f', 'medium', 'completed', '2023-12-27 06:02:29'),
(63, 1, 'Phone', 'v vjk sdfgsdhk', 'medium', 'active', '2023-12-27 07:07:43'),
(64, 1, 'vkf', 'xccsdfhsenfkwaeh', 'medium', 'inactive', '2023-12-27 07:08:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'Prashant', 'prashant@gmail.com', '123'),
(3, 'Sunil Band', 'sunilband@gmail.com', '123456'),
(6, 'Surya', 'surya@gmail.com', 'surya@123'),
(12, 'ABC', 'abc@gmail.com', 'ABC@1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
