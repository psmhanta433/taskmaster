<?php
include('connection.php');

$id=$_GET['id'];


$delete_query="DELETE FROM `task` WHERE id=$id";

$result_delete=mysqli_query($connection,$delete_query);
echo '<script>
window.location.href = "index.php";
alert("Yor are deleting this Data!");

// windows.location.href="index.php";
</script>';



?>

