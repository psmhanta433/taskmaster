<?php 
include('connection.php');
session_start();
$email=$_SESSION['email'];
$name="";
$id=0;
$sql="select * from users where email='$email'";
$result=mysqli_query($connection,$sql);

$selected_status='';

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location:login.php");
  
  exit;
}


if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
        $name=$row['name'];
        $id=$row['id'];        
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Task Master</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="body.css">
    <style>
        /* *{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body{
      width: 100%;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    } */
    
    #tooltip{
      position: relative;
      cursor: pointer;
      border-bottom: 2px;
      padding: 7px;
      font-size: 25px;
      font-weight: bold;
      font-family: Sans-Serif;
      color:#8c1aff ;
      
    }
    
    #tooltipText{
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
      background-color: #f2f2f2;
      color: #8c1aff;
      white-space: nowrap;
      padding: 10px 15px;
      border-radius: 7px;
      visibility: hidden;
      opacity: 0;
      transition: opacity 1s ease;
      font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }
    
    #tooltipText::before{
      content: "";
      position: absolute;
      left: 50%;
      top: -60%;
      transform: translateX(-50%);
      border: 15px solid ;
      border-color: #0000 #0000 #8c1aff #0000;
      font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }
    
    #tooltip:Hover #tooltipText{
      top: 30px;
      left: -5px;
      visibility: visible;
      opacity: 1;
      color: #f2f2ff;
      background-color: #8c1aff;
      font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }

    select{
        background-color: #8c1aff;
        color: #f2f2f2;
        border: none;
    }
    option{
        background-color: #8c1aff;
        color: #f2f2f2;
        border: none;
    }
    option:hover{
        background-color: #f2f2f2;
        color: #8c1aff;
    }
    </style>
</head>

<body>

    <?php 

    if(isset($_SESSION['status']) && $_SESSION['status']!='')
    {
        ?>
            swal(<?php echo $_SESSION['title'];?>, <?php echo $_SESSION['status'];?>, <?php echo $_SESSION['status_code'];?>);
        <?php
    }

    ?>

    <div class="navbar">
        <div class="logo">
            <i class='fas fa-clipboard' style='font-size:24px'></i>
            <a href="index.php">Task Master</a>
        </div>
        <div class="logo">
            
        </div>
        <a href="" id="tooltip">
            <p class="name_head" id="tooltipText"><?php echo $name?></p>
            <span><?php echo substr($name,0,1);?></span>
        </a>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    <?php 
    if(isset($_GET['status'])){
        $selected_status=$_GET['status'];
        $count_rows="SELECT * FROM task where u_id=$id AND status='$selected_status' ";
        $result=mysqli_query($connection,$count_rows);
        $count_rows=mysqli_num_rows($result);
    }
    else{
        $count_rows="SELECT * FROM task where u_id=$id ";
        $result=mysqli_query($connection,$count_rows);
        $count_rows=mysqli_num_rows($result);
    }
    
    

    ?>
    <p >Total <?php echo $count_rows; ?> Task</p>
    <?php 
    
    if($selected_status != '')
    {
        echo '<p id="selectedValue"> Status : '. ucfirst($selected_status).'</p>';
    }

    ?>
    <a href="index.php"><span class="glyphicon glyphicon-refresh"></span></a>
    <a href="add_task.php?id=<?php echo $id; ?>" class="add-new-btn">Add New +</a>

    
    <a class="add-new-btn">
        <select name="selectBox" id="selectBox" onchange="showSelectedValue(this.options[this.selectedIndex].value)">
            <option value="<?php echo $selected_status; ?>" selected>--Select Status--</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="completed">Completed</option>
        </select>
    </a>

    <script>
        function showSelectedValue(value) {
            let url="http://127.0.0.1/task_master_person/index.php";
                            window.location.href=url+"?status="+value;
        }
    </script>
    
    <br>
    
    <div class="container">
        <table id="myTable">
            <thead class="back">
            <tr>
                        <th> TASK</th>
                        <th> DESCRIPTION</th>
                        <th> PRIORITY</th>
                        <th> CREATED</th>
                        <th> Status</th>
                        <th> ACTIONS</th>
                    </tr>
            </thead>
            
            <?php 

            if(isset($_GET['status'])){
                

                $show_task="SELECT * FROM task where u_id=$id AND status='$selected_status'  ORDER BY id DESC";
                $result=mysqli_query($connection,$show_task);

                $count_rows=mysqli_num_rows($result);

              if(mysqli_num_rows($result)>0){
                echo "<tbody>";
                while($row=mysqli_fetch_assoc($result))
                {
                    echo "
                    <tr>
                    <td>".$row['task']."</td>
                    <td>".$row['description']."</td>";

                    if($row['priority'] == "high")
                    {
                        echo '<td>'.ucfirst($row['priority']).' &#8593</td>';
                    }
                    else if($row['priority'] == "medium")
                    {
                        echo '<td>'.ucfirst($row['priority']).' &#8594</td>';
                    }
                    else
                    {
                        echo '<td>'.ucfirst($row['priority']).' &#8595</td>';
                    }
                    
                    echo "<td>".date('d-m-Y',strtotime($row['date']))."
                    <br>
                    ".date('H : i',strtotime($row['date']))."
                    </td>
                    <td>".ucfirst($row['status'])."</td>
                    <td>
                        <a href='view_task.php?id=".$row['id']."''><u><i class='material-icons'>&#128065;</i></u></a>
                        <a href='update_task.php?id=".$row['id']."''><i class='material-icons'>edit</i></a>
                        <a href='delete_task.php?id=".$row['id']."''><i class='material-icons'>delete</i></a>
                    </td>
                </tr>";
                }
                echo "</tbody>";
              }


            }
            else{
                $show_task="SELECT * FROM task where u_id=$id  ORDER BY id DESC";
                $result=mysqli_query($connection,$show_task);
  
                if(mysqli_num_rows($result)>0){
                  echo "<tbody>";
                  while($row=mysqli_fetch_assoc($result))
                  {
                      echo "
                      <tr>
                      <td>".$row['task']."</td>
                      <td>".$row['description']."</td>";
  
                      if($row['priority'] == "high")
                      {
                          echo '<td>'.ucfirst($row['priority']).' &#8593</td>';
                      }
                      else if($row['priority'] == "medium")
                      {
                          echo '<td>'.ucfirst($row['priority']).' &#8594</td>';
                      }
                      else
                      {
                          echo '<td>'.ucfirst($row['priority']).' &#8595</td>';
                      }
                      
                      echo "<td>".date('d-m-Y',strtotime($row['date']))."
                      <br>
                      ".date('H : i',strtotime($row['date']))."
                      </td>
                      <td>".ucfirst($row['status'])."</td>
                      <td>
                          <a href='view_task.php?id=".$row['id']."''><u><i class='material-icons'>&#128065;</i></u></a>
                          <a href='update_task.php?id=".$row['id']."''><i class='material-icons'>edit</i></a>
                          <a href='delete_task.php?id=".$row['id']."''><i class='material-icons'>delete</i></a>
                      </td>
                  </tr>";
                  }
                  echo "</tbody>";
                }
  
            }

              
              
              ?>
                <!-- <tbody>
                    <tr><td>1</td><td>John Doe</td><td>john@example.com</td></tr>
                    <tr><td>2</td><td>Jane Smith</td><td>jane@example.com</td></tr>
                    <tr><td>3</td><td>Bob Johnson</td><td>bob@example.com</td></tr>
                    <tr><td>4</td><td>Alice Williams</td><td>alice@example.com</td></tr>
                    <tr><td>5</td><td>Mike Brown</td><td>mike@example.com</td></tr>
                    <tr><td>6</td><td>Sarah Miller</td><td>sarah@example.com</td></tr>
                </tbody> -->
        </table>
        
    </div>



    <!-- <div class="pagination">
        <button onclick="previousPage()" id="prevBtn" class="pagination-btn">Previous</button>
        <button onclick="nextPage()" id="nextBtn" class="next-btn">Next</button>
    </div> -->
</body>
<div class="pagination">
        <button onclick="previousPage()" id="prevBtn" class="pagination-btn">Previous</button>
        <button onclick="nextPage()" id="nextBtn" class="next-btn">Next</button>
    </div>
</html>


<script>
let currentPage = 1;
const rowsPerPage = 4;
const table = document.getElementById('myTable');
const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
const prevButton = document.getElementById('prevBtn');
const nextButton = document.getElementById('nextBtn');

function showRows(page) {
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    for (let i = 0; i < rows.length; i++) {
        rows[i].style.display = (i >= start && i < end) ? '' : 'none';
    }
}

function nextPage() {
    currentPage++;
    showRows(currentPage);
    updatePagination();
}

function previousPage() {
    currentPage--;
    showRows(currentPage);
    updatePagination();
}

function updatePagination() {
    const totalPages = Math.ceil(rows.length / rowsPerPage);
    prevButton.style.display = currentPage > 1 ? 'block' : 'none';
    nextButton.style.display = currentPage < totalPages ? 'block' : 'none';
}

showRows(currentPage);
updatePagination();
</script>

<style>
    #add_task{
        display: none;
    }
</style>

<!-- <script>

    function showForm(){
        var form=document.getElementById('add_task');
        form.style.display="block";
    }

</script>

<div class="container" id="add_task">
  <h2>Add Task</h2>

  <form id="taskForm" action="#" method="post">
    <div class="form-group">
      <label for="taskName">Task Name:</label>
      <input type="text" id="taskName" name="taskName">
    </div>
    <div class="form-group">
      <label for="description">Description:</label>
      <textarea id="description" name="description" rows="4" required></textarea>
    </div>
    <div class="form-group">
      <label for="priority">Priority:</label>
      <select id="priority" name="priority" required>
        <option value="" disabled selected>-- Select Priority --</option>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
    </div>
    <div class="form-group">
      <label for="status">Status:</label>
      <select id="status" name="status" required>
            <option value="" disabled selected>-- Select Status --</option>
            <option value="inactive">Inactive</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
      </select>
    </div>
    <div class="form-group">
      <button type="submit" name="add_task">Add Task</button>
    </div>
  </form>
</div> -->