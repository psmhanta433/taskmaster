<?php 

include ('connection.php');

$login=false;
$showError=false;




if(isset($_POST['login'])){
    $email=$_POST['email'];
    $password=$_POST['password'];

    $fetch=mysqli_query($connection,"SELECT * FROM users where email='$email' && password='$password'");

    if(mysqli_num_rows($fetch)>0){
      while($row=mysqli_fetch_assoc($fetch));
      {
          $login=true;

          session_start();
          $_SESSION['loggedin']=true;
          $_SESSION['email']=$email;

          

          echo "<script>
          window.location.href = 'index.php';
          alert('Welcome ".$email."!');
          </script>";
        
      }
    }
    else{
      $showError="Password do not Match";
      echo "<script>".$showError."</script>";
    }

}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="design.css">
    <script src="jquery.3.7.1.min.js"></script>
    <script src="toastr.min.js"></script>
    <link rel="stylesheet" href="toastr.min.css">
  </head>
  <body>
    <div class="navbar">
        <div class="navbar-title">TASKMASTER</div>
        <div class="navbar-buttons">
            <a href="signup.php" class="login-button">Sign Up</a>
        </div>
    </div>

    <section>
      <div class="wave wave1"></div>
      <div class="wave wave2"></div>
      <div class="wave wave3"></div>
      <div class="wave wave4"></div>
    </section>

    <div class="center">
      <h1>LOGIN</h1>
      <form method="post">
        <div class="txt_field">
          <input type="text" name="email" required>
          <span></span>
          <label>Email</label>
        </div>
        <div class="txt_field">
          <input type="password" name="password" required>
          <span></span>
          <label>Password</label>
        </div>
        <div class="pass">Forgot Password?          
        </div>
        
        <div class="submit_button">
            <input type="submit" name="login" value="Login">
        </div>

        <div class="design">
            ----------- O R -----------
        </div>
        <div class="signup_link">
            <a href="signup.php">Don't have an account</a>
        </div>
        
      </form>
    </div>
  </body>
</html>

