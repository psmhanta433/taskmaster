<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Login </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="design.css">
    <link rel="stylesheet" href="toastr.min.css">
</head>

<body>
        <script src="jquery.3.7.1.min.js"></script>
        <script src="toastr.min.js"></script>

    <div class="navbar">
        <div class="navbar-title">TASKMASTER</div>
        <div class="navbar-buttons">
            <a href="login.php" class="login-button">Login</a>
        </div>
    </div>

    <section>
        <div class="wave wave1"></div>
        <div class="wave wave2"></div>
        <div class="wave wave3"></div>
        <div class="wave wave4"></div>
    </section>

    <div class="center">
        <h1>SIGNUP</h1>
        <form method="post">
            <div class="txt_field">
                <input type="text" name="name" required>
                <span></span>
                <label>Name</label>
            </div>
            <div class="txt_field">
                <input type="email" name="email" required>
                <span></span>
                <label>Email</label>
            </div>
            <div class="txt_field">
                <input type="password" name="password" required>
                <span></span>
                <label>Password</label>
            </div>
            <div class="txt_field">
                <input type="password" name="confirm_password" required>
                <span></span>
                <label>Confirm Password</label>
            </div>


            <div class="submit_button">
                <input type="submit" name="submit" id="submit" value="Sign Up">
            </div>

            <div class="design">
                ----------- O R -----------
            </div>
            <div class="signup_link">
                <a href="login.php">Already have an account?</a>
            </div>
        </form>
    </div>
</body>

</html>


<?php 

include ('connection.php');

if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  $confirm_password=$_POST['confirm_password'];

  $mail_exist=mysqli_query($connection,"SELECT email from users WHERE email='$email'");

  if(mysqli_num_rows($mail_exist)>0){
    echo '<script>alert("Email ID is already Taken.!")</script>';
  }
  else{
    if(strlen($password)>=8)
    {
        if($password == $confirm_password){
    
            $insert_query="INSERT INTO `users`(`name`, `email`, `password`) VALUES ('$name','$email','$password')";
        
            $insert_result=mysqli_query($connection,$insert_query);
            
            echo "<script>
            window.location.href = 'login.php';
            alert('Your Account is Created!');            
            </script>";
          }
    }
    else{
        echo '<script>alert("Password Should be Minimum 8 Characters!")</script>';
        exit;
    }
      
  }
}

?>