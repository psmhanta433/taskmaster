    <!-- <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script> -->
    <!-- <script src="jquery.3.7.1.min.js"></script> -->
    <!-- <script src="toastr.min.js"></script> -->
    <!-- <link rel="stylesheet" href="toastr.min.css"> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script> -->
    <!-- <script src="sweetalert.js"></script> -->

    <!-- <script src="https://code.jquery.com/jquery-3.7.1.js" -->
        <!-- integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script> -->
    <script src="https://code.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- <?php 
    
    if(isset($_SESSION['data']) && $_SESSION['data']!='')
    {
        ?> -->
    <script>
        swal({
            title: "Good job!",
            text: "You clicked the button!",
            icon: "success",
            button: "Ok!",
        });
    </script>

    <?php 
    
    ?>
    <!-- <?php
    }

    ?> -->