<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Task Form</title>
  <link rel="stylesheet" href="update_task.css">
  <style>
    #container{
      display: none;
    }

    .show-btn{
      /* margin: 0 300px; */
      margin:0 725px;
    }

    #msg{
      font-size: medium;
      font-weight: 500;
      vertical-align: middle;
      text-align: center;
    }
    #ok{
      display: block;
      /* width: 80px;
      height: 20px; */
      margin: 10px auto;
    }
  </style>
</head>
<body>
  <script>
    function showme(){
      var alert=document.getElementById('container');
      alert.style.display="block";
    }

    function hide(){
      var alert=document.getElementById('container');
      alert.style.display="none";
    }
  </script>
<?php 
include ('connection.php');
$id=$_GET['id'];

$taskName=$description=$priority=$status="";

$get_data="SELECT * FROM task where id=$id";
$result_data=mysqli_query($connection,$get_data);

if(mysqli_num_rows($result_data)>0){
    while($row=mysqli_fetch_assoc($result_data))
    {
        $taskName=$row['task'];
        $description=$row['description'];
        $priority=$row['priority'];
        $status=$row['status'];
    }
}


if(isset($_POST['update'])){
  $taskName_update=$_POST['taskName'];
  $description_update=$_POST['description'];
  $priority_update=$_POST['priority'];
  $status_update=$_POST['status'];

  if($taskName == $taskName_update && $description == $description_update && $priority == $priority_update && $status == $status_update){
    echo '<script>
    alert("Nothing Changes in Data");
    window.location.href = "index.php";
    </script>';
  }
  else{
    $update_query="UPDATE `task` SET `task`='$taskName_update',`description`='$description_update',`priority`='$priority_update',`status`='$status_update' WHERE id=$id";
    $result_update=mysqli_query($connection,$update_query);
  
    if(mysqli_query($connection,$update_query))
    {
      echo '<script>
      alert("Data Updated Successfully");
      window.location.href = "index.php";
      </script>';
  
    }
  }

  
  
}


?>
<div class="container">
  <h2>Update Task</h2>
  <form id="taskForm" action="#" method="post">
    <div class="form-group">
      <label for="taskName">Task Name:</label>
      <input type="text" value="<?php echo $taskName; ?>" id="taskName" name="taskName" required>
    </div>
    <div class="form-group">
      <label for="description">Description:</label>
      <textarea id="description" name="description" rows="4" required><?php echo $description?></textarea>
    </div>
    <div class="form-group">
      <label for="priority">Priority:</label>
      <select id="priority" name="priority" required>
        <option value="<?php echo $priority; ?>" selected><?php echo ucfirst($priority); ?></option>
        <label for=""></label>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
    </div>
    <div class="form-group">
      <label for="status">Status:</label>
      <select id="status" name="status" required>
        <option value="<?php echo $status; ?>" selected><?php echo ucfirst($status); ?></option>
        <option value="inactive">Inactive</option>
        <option value="active">Active</option>
        <option value="completed" >Completed</option>
      </select>
    </div>
    <div class="form-group">
      <button type="submit" name="update" id="update" onclick="showme()">Update</button>
    </div>
  </form>
</div>
<!-- <div id="container">
  <div id="msg">Data Updated Successfully!</div>
  <button id="ok" onclick="hide()">OK</button>
</div>
<button id="showme" class="show-btn" onclick="showme()">Update</button> -->
</body>
</html>
