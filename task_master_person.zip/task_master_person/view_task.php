<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Task Form</title>
  <!-- <link rel="stylesheet" href="styles.css"> -->
  <style>
    /* Basic CSS for styling the form */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

.container {
  width: 30%;
  margin: 50px auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background: #eee;
}

h2 {
  text-align: center;
  color: #555;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
  color: #555;
}

.display {
  /* width: 90%; */
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 10px;
  color: #555;
  background: #fff;
}

input[type="text"],
select,
textarea {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 10px;
  color: #555;
}

textarea {
  resize: vertical;
}

option{
    background: #eee;
    margin: 5px;
}

option:hover{
    background: #555;
}

.login-button {
  padding: 10px 20px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  height: 40px;
  text-decoration: none;
}

.login-button:hover {
  background-color: #66a3ff;
  color: #eee;
}

  </style>
</head>
<body>
<?php 
include ('connection.php');
$id=$_GET['id'];
// echo $id;

$taskName=$description=$priority=$status="";

$get_data="SELECT * FROM task where id=$id";
$result_data=mysqli_query($connection,$get_data);

if(mysqli_num_rows($result_data)>0){
    while($row=mysqli_fetch_assoc($result_data))
    {
        $taskName=$row['task'];
        $description=$row['description'];
        $priority=$row['priority'];
        $status=$row['status'];
    }
}

?>
<div class="container">
  <h2>View Task</h2>
  <form id="taskForm" action="#" method="post">
    <div class="form-group">
      <label for="taskName"><b>Task Name:</b></label>
      <label for="" class="display"><?php echo $taskName; ?></label>
      <hr>
    </div>
    <div class="form-group">
      <label for="taskName"><b>Description:</b></label>
      <label for="" class="display"><?php echo $description; ?></label>
      <hr>
    </div>
    <div class="form-group">
      <label for="taskName"><b>Priority:</b></label>
      <label for="" class="display"><?php echo ucfirst($priority); ?></label>
      <hr>
    </div>
    <div class="form-group">
      <label for="taskName"><b>Status:</b></label>
      <label for="" class="display"><?php echo ucfirst($status); ?></label>
      <hr>
    </div>

    <a href="index.php" class="login-button">Back</a>
  </form>
</div>

</body>
</html>

